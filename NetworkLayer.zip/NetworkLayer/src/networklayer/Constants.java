/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package networklayer;

/**
 *
 * @author samsung
 */
public interface Constants {
    static final int INFTY = 10;
    static final double LAMBDA = 0.10;
}
